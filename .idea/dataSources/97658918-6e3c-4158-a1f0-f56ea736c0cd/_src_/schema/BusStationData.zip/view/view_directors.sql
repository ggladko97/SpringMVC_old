CREATE VIEW `view_directors` AS
  SELECT
    `BusStationData`.`Directors`.`id` AS `id`,
    `BusStationData`.`Directors`.`director_name` AS `director_name`,
    `BusStationData`.`Directors`.`director_ballance` AS `director_ballance`
  FROM `BusStationData`.`Directors`