CREATE PROCEDURE `checkStatusofStation`(IN `station_name_I` VARCHAR(30))
  BEGIN
DECLARE aval INT DEFAULT 0;


SELECT station_availability INTO aval FROM Stations WHERE Stations.station_name = (SELECT id FROM Names WHERE Names.name=station_name_I) LIMIT 1;

IF aval = 5 THEN 
SELECT 'work';
ELSEIF aval = 1 THEN
SELECT 'closed';
ELSE
SELECT 'reconstruction';
END IF;
END