CREATE FUNCTION `OwnerBalanceByName`(`owner_name` VARCHAR(30))
  RETURNS VARCHAR(50)
BEGIN
  DECLARE balance VARCHAR(50);
 
  SELECT director_ballance INTO balance
    FROM Directors
    WHERE director_name=owner_name;
    
  RETURN balance;
END